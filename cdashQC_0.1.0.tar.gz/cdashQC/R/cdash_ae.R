#' createaet.
#'
#' @title do what createaet does.
#' @param dm  the dataset dm read from sas
#' @param ex  the dataset ex read from sas
#' @param included  the dataset included from sas
#' @return aet the data
#' @export
#'


create_aet <- function(ae, ex, included, improv = 99){
  ae$ptno <- as.numeric(ae$CLIENTID)
  # pay attention to | (elementwise use of "or") and || (overall evaluation)
  ids <- ae$AE_TERM == "" | ae$AE_YN == "NO"
  ae$AE_TERM[ids] <- "NONE"
  # start date and time of ae
  ae$ondate <- parse_date_time(paste(ymd(ae$AE_STDT), hms(ae$AE_STTM)), "Ymd HMS", truncated = 3)
  # recovery date and time of ae
  ae$redate <- parse_date_time(paste(ymd(ae$AE_ENDT), hms(ae$AE_ENTM)), "Ymd HMS", truncated = 3)
  ae <- arrange(ae, ptno)   # sort by ptno


  #  start date and time of treatement
  ex$ptno <- as.numeric(ex$CLIENTID)
  ex$meddt <- parse_date_time(paste(ymd(ex$EX_STDAT), hms(ex$EX_STTIM)), "Ymd HMS", truncated = 3)
  select_col <- which(names(ex) %in% c("ptno", "meddt", "PERIOD"))
  med <- data.frame(ex[!is.na(ex$meddt), select_col])  %>%
    arrange(ptno, meddt) %>% mutate(medper = PERIOD) %>% select(-PERIOD) # remove NAs
  firstmed <- med  %>% group_by(ptno) %>%  # group by ptno
              filter(row_number(ptno)==1)    # select distinct values  (first.obs)


  # prior: ae prior dosing
  prior <- inner_join(firstmed, ae, by = "ptno") %>%
    dplyr::filter(ondate < meddt & (!is.na(ondate)))   # select those AEs occurred before dosing

  # after (no distinct value, because there might be multiple period)
  after <- inner_join(med, ae, by = "ptno") %>%
    dplyr::filter(ondate >= meddt | is.na(ondate) ) %>%
               mutate(timediff = ondate-meddt)  # create timediff variable

  # separate "after" to three types
  # final1a = on study
  # final1b = unknown times
  # final1c = No AEs

  new <- after %>% arrange(ptno, AE_NO, AE_TERM, ondate, timediff)  # order the variables
  # select the first obs where ondate is not missing
  final1a <- new %>% dplyr::filter(row_number(ondate)==1 & !(is.na(ondate)))
  finalb <- new %>% dplyr::filter(is.na(ondate)) %>% group_by(ptno, AE_NO, AE_TERM)
  final1b <- finalb %>% dplyr::filter(row_number(AE_TERM)==1 & (AE_TERM != "NONE"))  # select distinct values
  final1c <- finalb %>% dplyr::filter(  !( (row_number(AE_TERM)==1)  &  (AE_TERM != "NONE") )  )

  final <- bind_rows(prior, final1a, final1b, final1c) %>% # efficient way to rbind
          arrange(ptno)
  if ( nrow(final) != nrow(ae)) stop("ERROR: You are losing observations (Duplicates Maybe?)")
  final$duration = as.period(interval(as.POSIXct(final$ondate), as.POSIXct(final$redate)))

  included1 <- included %>% mutate(ptno = as.numeric(PTNO), seq = SEQ) %>% select(ptno, seq)
  final <- left_join(final, included1, by = "ptno")
  ids <- toupper(final$medper) %in% c('PREDOSE','CC','CREATININE CLEARANCE','SCREENING','ALL','UNKNOWN','UNK','SCREEN')
  final <- final[!ids, ] %>% mutate(pernew = as.numeric(substr(medper, 1, 1)),
                                      treat = substr(seq, pernew, pernew) ) %>%
                              arrange(ptno, ondate, AE_TERM)  #sort

  final$t_e <- ifelse(is.na(final$duration), "NO", "YES")

  improve <- final %>%  dplyr::filter(AE_OUT==improv)
  if (nrow(improve) > 0){ # if the improve data is not empty
     improve <- improve %>%
        mutate(ondate = parse_date_time(paste(ymd(AE_ENDT), hms(AE_ENTM)), "Ymd HMS", truncated = 3)) %>%
        select(ptno, ondate, AE_TERM)  %>% arrange(ptno, ondate, AE_TERM)

      final <- full_join(final, improve, by = c("ptno", "ondate", "AE_TERM"))
    }

   aet <- final %>% mutate(pern = as.numeric(pernew)) %>% select(-pernew, -seq, -timediff)
   aet$treat[aet$t_e == "NO" | toupper(ae$AE_TERM) == "NONE"] <- " "

   return(aet)
  }



#' ae1
#'
#' @title Create Adverse event list.
#' @param aet  the dataset dm read from sas
#' @param bytrt listed by treatment?
#' @param ex  the dataset ex read from sas, used only when \code{bytrt = T}.
#' @return a data frame or a list (if needs to be listed by treatment)
#' @export
#'
ae1 <- function(aet, bytrt = F, ex = ex){

  aet <- left_join(aet %>% arrange(CLIENTID),
                   ex%>% select(CLIENTID, EX_TRT_C),
                   by = "CLIENTID")
  treatment <- unique(aet$EX_TRT_C)

  show_var <- c("ptno", "pern","t_e", "AE_TERM", "AE_STDT", "AE_STTM",  "AE_ENDT",
                "AE_ENTM", "duration", "EX_TRT_C")
  o1 <- c()
  for(i in 1:length(show_var)) {
    o1[i] <- which(names(aet)== show_var[i])
  }

  result <- list()

  if (bytrt){
    for ( k in 1:length(treatment)) {
      ids <- aet$EX_TRT_C == treatment[k]
      res <- aet[ids, o1]  %>%
            mutate(AE_STTM = seconds_to_period(AE_STTM),
                   AE_ENTM = seconds_to_period(AE_ENTM))
      result[[treatment[k]]] <- res
    }
    return(result)
  }
  else{
    result <- aet[, o1] %>% mutate(AE_STTM = seconds_to_period(AE_STTM),
                                  AE_ENTM = seconds_to_period(AE_ENTM))
    result <- as.data.frame(result)
    return(result)
  }

}



#' ae2
#'
#' @title list Adverse Envent 2.
#' @param aet the dataset dm read from sas
#' @param bytrt listed by treatment?
#' @param ex  the dataset ex read from sas, used only when \code{bytrt = T}.
#' @return a data frame or a list (if needs to be listed by treatment)
#' @export
#'
ae2 <- function(aet, bytrt = F, ex = ex){

  aet <- left_join(aet %>% arrange(CLIENTID),
                   ex%>% select(CLIENTID, EX_TRT_C),
                   by = "CLIENTID")
  treatment <- unique(aet$EX_TRT_C)

  show_var <- c("ptno", "pern", "EX_TRT_C", "AE_TERM", "AE_STDT", "AE_STTM", "AE_FRQ_D",
                "AE_SEV_D", "AE_SER_D", "AE_OUT_D", "AE_REL_D","AE_ACT_D", "AE_AN1_D")
  o1 <- c()
  for(i in 1:length(show_var)) {
    o1[i] <- which(names(aet)== show_var[i])
  }

  result <- list()

  if (bytrt){
    for ( k in 1:length(treatment)) {
      ids <- aet$EX_TRT_C == treatment[k]
      res <- aet[ids, o1]  %>%
        mutate(AE_STTM = seconds_to_period(AE_STTM))
      result[[treatment[k]]] <- res
    }
    return(result)
  }
  else{
    result <- aet[, o1] %>% mutate(AE_STTM = seconds_to_period(AE_STTM))
    result <- as.data.frame(result)
    return(result)
  }

}






#' ae3
#'
#' @title list Adverse Envent Non Drug Therapy.
#' @param aet  the dataset dm read from sas
#' @param bytrt listed by treatment?
#' @param ex  the dataset ex read from sas, used only when \code{bytrt = T}.
#' @return a data frame or a list (if needs to be listed by treatment)
#' @export
#'

ae3 <- function(aet, bytrt = F, ex = ex){

  aet <- left_join(aet %>% arrange(CLIENTID),
                   ex%>% select(CLIENTID, EX_TRT_C),
                   by = "CLIENTID")

  aet_s <- aet %>% dplyr::filter(trimws(AE_P1) != "")

  treatment <- unique(aet_s$EX_TRT_C)

  show_var <- c("ptno", "pern", "EX_TRT_C", "AE_TERM", "AE_STDT", "AE_STTM",
                "AE_PDT1","AE_PTM1", "AE_P1")
  o1 <- c()
  for(i in 1:length(show_var)) {
    o1[i] <- which(names(aet_s)== show_var[i])
  }

  result <- list()

  if (bytrt){
    for ( k in 1:length(treatment)) {
      ids <- aet_s$EX_TRT_C == treatment[k]
      res <- aet_s[ids, o1]  %>%
        mutate(AE_STTM = seconds_to_period(AE_STTM),
               AE_PTM1 = seconds_to_period(AE_PTM1))
      result[[treatment[k]]] <- res
    }
    return(result)
  }
  else{
    result <- aet_s[, o1] %>% mutate(AE_STTM = seconds_to_period(AE_STTM),
                                     AE_PTM1 = seconds_to_period(AE_PTM1))
    result <- as.data.frame(result)
    return(result)
  }

}



